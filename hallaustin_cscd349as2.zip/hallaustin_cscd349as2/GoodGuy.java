
public class GoodGuy {
	private int HobbitCount;
	private int ElfCount;
	private int DwarveCount;
	private int ManCount;

	public GoodGuy(int hobbit, int elf, int dwarve, int man) {
		this.HobbitCount = hobbit;
		this.ElfCount = elf;
		this.DwarveCount = dwarve;
		this.ManCount = man;
	}

	public int getHobbitCount() {
		return HobbitCount;
	}

	public int getElfCount() {
		return ElfCount;
	}

	public int getDwarveCount() {
		return DwarveCount;
	}

	public int getManCount() {
		return ManCount;
	}

	public void setEnemies(GoodGuy goodGuys) {

	}
}

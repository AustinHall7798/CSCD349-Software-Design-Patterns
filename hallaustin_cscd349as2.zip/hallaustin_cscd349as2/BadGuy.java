import java.util.Observable;
import java.util.Observer;
public class BadGuy implements Observer{
	
	private EyeOfSauron eye;
	private String name;

	public BadGuy(EyeOfSauron eye, String name) {
		this.eye = eye;
		this.name = name;
		this.eye.addObserver(this);
	}

	public void defeated() {
		System.out.println(this.name + " was defeated");
		eye.deleteObserver(this);
	}

	@Override
	public void update(Observable o, Object arg) {
		System.out.println(this.name + " knows about " + ((GoodGuy) arg).getHobbitCount() + " hobbits, " + 
				((GoodGuy) arg).getElfCount() + " elves, " + ((GoodGuy) arg).getDwarveCount() + " dwarves, and " +
				((GoodGuy) arg).getManCount() + " men");
		
	}

}

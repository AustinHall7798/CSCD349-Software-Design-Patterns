import java.util.Observable;

public class EyeOfSauron extends Observable {

	public void setEnemies(int hobbit, int elf, int dwarve, int man) {
		this.setChanged();
		this.notifyObservers(new GoodGuy(hobbit, elf, dwarve, man));
	}

}

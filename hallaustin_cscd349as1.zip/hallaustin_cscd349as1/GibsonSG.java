
public class GibsonSG implements GuitarBehavior{

	@Override
	public void playGuitar() {
		System.out.println(" is playing the Gibson SG guitar");
		
	}

}


public interface GuitarBehavior {

	public void playGuitar();
}


public class GameCharacterSlash extends GameCharacter {
	
	public GameCharacterSlash() throws Exception {
		super(new GibsonFlyingV(), new FireGuitar(), "Slash");
	}
}

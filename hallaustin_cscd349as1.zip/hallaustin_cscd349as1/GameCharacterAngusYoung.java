
public class GameCharacterAngusYoung extends GameCharacter{

	public GameCharacterAngusYoung() throws Exception {
		super(new Fender(), new JumpOffStage(), "Angus Young");
	}
}

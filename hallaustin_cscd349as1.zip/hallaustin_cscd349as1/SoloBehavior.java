
public interface SoloBehavior {

	public void playSolo();
}

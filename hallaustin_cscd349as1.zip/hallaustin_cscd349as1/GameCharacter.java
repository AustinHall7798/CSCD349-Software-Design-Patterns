
public abstract class GameCharacter {

	private GuitarBehavior PlayGuitar;
	private SoloBehavior PlaySolo;
	private String Name;
	
	public GameCharacter(GuitarBehavior guitar, SoloBehavior solo, String name) throws Exception {
		setGuitar(guitar);
		setSolo(solo);
		this.Name = name;
	}
	
	public void setGuitar(GuitarBehavior guitar) throws Exception {
		if(guitar == null) 
			throw new IllegalArgumentException("Guitar is null");
		this.PlayGuitar = guitar;
	}
	
	public void setSolo(SoloBehavior solo) {
		if(solo == null) 
			throw new IllegalArgumentException("Solo is null");
		this.PlaySolo = solo;
	}
	
	public void playGuitar() {
		System.out.print(this.Name);
		PlayGuitar.playGuitar();
	}
	
	public void playSolo() {
		System.out.print(this.Name);
		PlaySolo.playSolo();
	}
}


public class GameCharacterHendrix extends GameCharacter {

	public GameCharacterHendrix() throws Exception {
		super(new GibsonSG(), new SmashGuitar(), "Hendrix");
	}
}


public class Fender implements GuitarBehavior{

	@Override
	public void playGuitar() {
		System.out.println(" is playing the Fender Telecaster");
		
	}

}

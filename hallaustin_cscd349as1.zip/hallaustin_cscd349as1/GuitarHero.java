public class GuitarHero {
    public static void main(String[] args) throws Exception {
        GameCharacter player1 = new GameCharacterSlash(); //note that constructor could be designed to accept initial behaviors
        GameCharacter player2 = new GameCharacterHendrix();
        GameCharacter player3 = new GameCharacterAngusYoung();
        player1.playGuitar();
        player2.playGuitar();
        player3.playGuitar();
        player1.playSolo();
        player2.playSolo();
        player3.playSolo();

        player1.setGuitar(new Fender());
        player1.playGuitar();
        player2.setSolo(new JumpOffStage());
        player2.playSolo();
        player3.setSolo(new FireGuitar());
        player3.playSolo();
        //add code below to show the swapping of behaviors
    }
}


public class FireGuitar implements SoloBehavior{
	
	@Override
	public void playSolo() {
		System.out.println(" just set his guitar on fire");
	}

}

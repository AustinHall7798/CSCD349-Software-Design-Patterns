
public class SmashGuitar implements SoloBehavior{

	@Override
	public void playSolo() {
		System.out.println(" smashed his guitar");
		
	}

}

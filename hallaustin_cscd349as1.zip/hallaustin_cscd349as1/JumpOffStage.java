
public class JumpOffStage implements SoloBehavior{

	@Override
	public void playSolo() {
		System.out.println(" jumped off the stage");
		
	}

}

AUSTIN HALL

There are no short comings in my Fraction class.
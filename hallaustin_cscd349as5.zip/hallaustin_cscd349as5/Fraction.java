// AUSTIN HALL

package fraction;

public class Fraction {

	private int num;
	private int den;

	public Fraction(int num, int dem) {
		int gcd;
		if (dem == 0)
			throw new IllegalArgumentException("The denominator with the value of 0 is not permitted");
		if (num == 0) {
			this.num = 0;
			this.den = 1;
		} else {
			this.num = num;
			this.den = dem;
		}
		if (dem < 0) {
			this.den = -1 * this.den;
			this.num = -1 * this.num;
		}
		gcd = gcd(this.num, this.den);
		this.num = this.num / gcd;
		this.den = this.den / gcd;
	}

	public int getNum() {
		return this.num;
	}

	public int getDen() {
		return this.den;
	}

	public int compareTo(Fraction fraction) {
		double newNum = ((double) this.num) / ((double) this.den);
		double newFraction = ((double) fraction.num) / ((double) fraction.den);
		if (newNum < newFraction)
			return -1;
		else if (newNum > newFraction)
			return 2;
		else
			return 0;
	}

	public boolean equals(Fraction fraction) {
		if (fraction.den == this.den && fraction.num == this.num)
			return true;
		return false;
	}

	public Fraction add(Fraction fraction) {
		if (fraction == null) {
			throw new IllegalArgumentException("Cannot perform math operations on a null fraction object!");
		}
		int newNum = fraction.num + this.num;
		return new Fraction(newNum, this.den);
	}

	public Fraction multiply(Fraction fraction) {
		if (fraction == null) {
			throw new IllegalArgumentException("Cannot perform math operations on a null fraction object!");
		}
		return new Fraction(this.num * fraction.num, this.den * fraction.den);
	}

	public double realValue() {
		return (double) this.num / (double) this.den;
	}

	public static int gcd(int a, int b) {
		if (a < 0)
			a = -a;
		if (b < 0)
			b = -b;
		int t;
		while (b != 0) {
			t = b;
			b = a % b;
			a = t;
		}
		return a;
	}

	@Override
	public String toString() {
		return num + "/" + den;
	}

}

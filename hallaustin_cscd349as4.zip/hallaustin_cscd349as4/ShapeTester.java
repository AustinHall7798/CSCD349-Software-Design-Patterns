import java.util.ArrayList;
import java.util.Collections;

import Shapes.Shape;
import Shapes.ShapeFactory;

public class ShapeTester {

	public static void main(String[] args) {
		ArrayList<Shape> list = new ArrayList<Shape>();
		ShapeFactory factory = new ShapeFactory();
		
		list.add(factory.createTriangle(4, 2));
		list.add(factory.createTriangle(6, 1));
		list.add(factory.createTriangle(5, 9));

		list.add(factory.createRectangle(2, 6));
		list.add(factory.createRectangle(4, 8));
		list.add(factory.createRectangle(2, 23));
		
		list.add(factory.createSquare(6));
		list.add(factory.createSquare(3));
		list.add(factory.createSquare(9));
		
		list.add(factory.createCircle(5));
		list.add(factory.createCircle(7));
		list.add(factory.createCircle(2));		
		
		System.out.println("List before sorting:");
		for (Shape shape: list) {
			printResults(shape);
		}
		
		Collections.sort(list);
		System.out.println("List after sorting: ");
		for (Shape shape: list) {
			printResults(shape);
		}
	}

	private static void printResults(Shape shape) {
		System.out.println("Area of the " + shape.name() + " is " + shape.area());
	}
}

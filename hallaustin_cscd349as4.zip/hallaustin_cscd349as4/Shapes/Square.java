package Shapes;

public class Square extends Shape{

	private double height;
	
	protected Square(int height) {
		this.height = height;
	}
	
	@Override
	public int compareTo(Shape o) {
		if(this.name().compareTo(o.name()) == 0) {
			if(this.area() == o.area()) 
				return 0;
			else if(this.area() > o.area())
				return 1;
			else
				return -1;
 		} 
		else
 			return (this.name().compareTo(o.name()));
	}

	@Override
	public double area() {
		return height * height;
	}

	@Override
	public String name() {
		return "square";
	}

}

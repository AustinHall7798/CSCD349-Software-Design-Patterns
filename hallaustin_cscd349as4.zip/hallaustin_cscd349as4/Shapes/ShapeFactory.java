package Shapes;

public class ShapeFactory {

	public Circle createCircle(int radius) {
		return new Circle(radius);
		
	}
	
	public Rectangle createRectangle(int height, int width) {
		return new Rectangle(width, height);
		
	}
	
	public Square createSquare(int height) {
		return new Square(height);
		
	}
	
	public Triangle createTriangle(int height, int width) {
		return new Triangle(height, width);
		
	}
	
}

package Shapes;

public class Rectangle extends Shape{

	private double height;
	private double width;
	
	protected Rectangle(int height, int width) {
		this.height = height;
		this.width = width;
	}
	
	@Override
	public int compareTo(Shape o) {
		if(this.name().compareTo(o.name()) == 0) {
			if(this.area() == o.area()) 
				return 0;
			else if(this.area() > o.area())
				return 1;
			else
				return -1;
 		} 
		else
 			return (this.name().compareTo(o.name()));
	}

	@Override
	public double area() {
		// TODO Auto-generated method stub
		return width * height;
	}

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "rectangle";
	}

}

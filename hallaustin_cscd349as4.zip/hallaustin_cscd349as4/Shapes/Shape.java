package Shapes;

public abstract class Shape implements Comparable<Shape>{

	public abstract double area();
	public abstract String name();
	public abstract int compareTo(Shape shape);
}

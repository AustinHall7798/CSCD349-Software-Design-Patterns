package Shapes;

public class Triangle extends Shape{

	private double height;
	private double width;
	
	protected Triangle(int height, int width) {
		this.height = height;
		this.width = width;
	}
	
	@Override
	public int compareTo(Shape o) {
		if(this.name().compareTo(o.name()) == 0) {
			if(this.area() == o.area()) 
				return 0;
			else if(this.area() > o.area())
				return 1;
			else
				return -1;
 		} 
		else
 			return (this.name().compareTo(o.name()));
	}

	@Override
	public double area() {
		return width * height / 2.0;
	}

	@Override
	public String name() {
		return "triangle";
	}

}

import holiday_decorations.BallsBlue;
import holiday_decorations.BallsRed;
import holiday_decorations.BlueSpruce;
import holiday_decorations.FraserFir;
import holiday_decorations.LEDs;
import holiday_decorations.Lights;
import holiday_decorations.Ribbons;
import holiday_decorations.Ruffles;
import holiday_decorations.Star;
import holiday_decorations.HolidayItem;

public class TreeTester {
	
	public static void main(String[] args) {
	HolidayItem mytree = new BlueSpruce();
	mytree = Star.getStar(mytree);
	mytree = new Ruffles(mytree);
	mytree = new LEDs(mytree);
	mytree = new BallsBlue(mytree);
	mytree = new BallsRed(mytree);
	mytree = new Lights(mytree);
	mytree = Star.getStar(mytree);
	printTree(mytree);
	
	HolidayItem newTree = new  FraserFir();
	newTree = Star.getStar(newTree);
	newTree = new Ruffles(newTree);
	newTree = new LEDs(newTree);
	newTree = new BallsBlue(newTree);
	newTree = Star.getStar(newTree);
	newTree = new Ribbons(newTree);
	printTree(newTree);
	}

	private static void printTree(HolidayItem mytree) {
		System.out.println(mytree.description() + " and costs $" + mytree.cost());
	}
}

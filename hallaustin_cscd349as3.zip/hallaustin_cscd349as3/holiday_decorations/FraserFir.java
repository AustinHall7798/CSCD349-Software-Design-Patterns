package holiday_decorations;

public class FraserFir implements HolidayItem {

	@Override
	public double cost() {
		return 35;
	}

	@Override
	public String description() {
		return "The tree is a Fraser Fir decorated with";
		
	}

}

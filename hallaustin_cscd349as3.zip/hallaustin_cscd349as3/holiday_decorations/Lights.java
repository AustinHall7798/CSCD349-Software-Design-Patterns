package holiday_decorations;

public class Lights extends HolidayDecoration {
	
	public Lights(HolidayItem item) {
		super(item);
	}

	@Override
	public double cost() {
		return 5 + getWrappedItem().cost();
	}

	@Override
	public String description() {
		return getWrappedItem().description() + " Lights,";
	}

}

package holiday_decorations;

public class LEDs extends HolidayDecoration {
	
	public LEDs(HolidayItem item) {
		super(item);
	}

	@Override
	public double cost() {
		return 10 + getWrappedItem().cost();
	}

	@Override
	public String description() {
		return getWrappedItem().description() + " LEDs,";
	}

}

package holiday_decorations;

public class BalsamFir implements HolidayItem {

	@Override
	public double cost() {
		return 25;
	}

	@Override
	public String description() {
		return "The tree is a Balsam Fir decorated with";
		
	}

}

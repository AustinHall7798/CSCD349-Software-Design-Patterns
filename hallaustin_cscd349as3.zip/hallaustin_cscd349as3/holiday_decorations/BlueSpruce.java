package holiday_decorations;

public class BlueSpruce implements HolidayItem {

	@Override
	public double cost() {
		return 50;
	}

	@Override
	public String description() {
		return "The tree is a Blue Spruce decorated with";
		
	}

}

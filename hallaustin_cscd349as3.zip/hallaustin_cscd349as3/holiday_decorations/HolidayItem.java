package holiday_decorations;

public interface HolidayItem {

	public double cost();
	public String description();
}

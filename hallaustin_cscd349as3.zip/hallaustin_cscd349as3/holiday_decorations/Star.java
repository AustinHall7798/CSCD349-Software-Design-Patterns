package holiday_decorations;

public class Star extends HolidayDecoration{
	private Star(HolidayItem item) {
		super(item);
	}

	@Override
	public double cost() {
		return 4 + getWrappedItem().cost();
	}

	@Override
	public String description() {
		return getWrappedItem().description() + " a Star,";
	}

	public static HolidayItem getStar(HolidayItem item) {
		if(!item.description().contains("Star"))
			return new Star(item);
		System.out.println("The tree already has a Star");
		return item;
	}
}

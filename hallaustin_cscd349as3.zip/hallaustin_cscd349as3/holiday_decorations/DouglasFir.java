package holiday_decorations;

public class DouglasFir implements HolidayItem {

	@Override
	public double cost() {
		return 30;
	}

	@Override
	public String description() {
		return "The tree is a Douglas Fir decorated with";
		
	}

}

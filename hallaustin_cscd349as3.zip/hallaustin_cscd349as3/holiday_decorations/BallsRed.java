package holiday_decorations;

public class BallsRed extends HolidayDecoration {
	
	public BallsRed(HolidayItem item) {
		super(item);
	}

	@Override
	public double cost() {
		return 1 + getWrappedItem().cost();
	}

	@Override
	public String description() {
		return getWrappedItem().description() + " Red Balls,";
	}

}
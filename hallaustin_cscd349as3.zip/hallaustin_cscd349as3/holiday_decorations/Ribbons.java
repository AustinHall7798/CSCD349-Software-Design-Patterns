package holiday_decorations;

public class Ribbons extends HolidayDecoration {
	
	public Ribbons(HolidayItem item) {
		super(item);
	}

	@Override
	public double cost() {
		return 2 + getWrappedItem().cost();
	}

	@Override
	public String description() {
		return getWrappedItem().description() + " Ribbons,";
	}

}
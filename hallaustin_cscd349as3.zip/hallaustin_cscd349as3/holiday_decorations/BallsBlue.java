package holiday_decorations;

public class BallsBlue extends HolidayDecoration {
	
	public BallsBlue(HolidayItem item) {
		super(item);
	}

	@Override
	public double cost() {
		return 2 + getWrappedItem().cost();
	}

	@Override
	public String description() {
		return getWrappedItem().description() + " Blue Balls,";
	}

}